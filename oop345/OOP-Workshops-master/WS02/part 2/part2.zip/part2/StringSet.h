#include <iostream> 
#include <fstream>
#include <string>
using namespace std; 

namespace sdds{
class StringSet{
  private:
    int numberOfWords;
    string*words;
  public:
  StringSet();
  StringSet(string name);
  size_t size();
  string operator[](size_t index);
  StringSet(StringSet&&);
  StringSet(StringSet&);
  StringSet& operator=(StringSet& obj);
  StringSet& operator=(StringSet&&);
  };
}